﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

namespace SwitcherUI
{
    /// <summary>
    /// Interaction logic for Login.xaml
    /// </summary>
    public partial class Login : UserControl, ISwitchable
    {
        SqlConnection cn = null;
        SqlCommand cmd = new SqlCommand();
        SqlDataReader dr = null;

        public Login()
        {
            InitializeComponent();
            cn = new SqlConnection(ConfigurationManager.ConnectionStrings["con"].ConnectionString);
        }

        private void BtnLogin_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                int loginId = Convert.ToInt32(txtLoginId.Text);
                string password = txtPassword.Password;


                cmd.CommandText = "Select * from PolicyEn.[Login] "
                            + "where LoginId = '" + loginId + "' "
                            + "and passwd = '" + password + "'";

                cmd.CommandType = CommandType.Text;
                cmd.Connection = cn;
                cn.Open();
                dr = cmd.ExecuteReader();

                int i = 0;

                while (dr.Read())
                {
                    i++;
                }
                
                if (i == 1)
                {
                    Switcher.Switch(new HomePage());
                }
                else
                {
                    MessageBox.Show("INCORRECT PASSWORD OR USER ID", "Authentication Failed");
                    txtLoginId.Text = String.Empty;
                    txtPassword.Password = String.Empty;
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Catch Block = " + ex);
            }
            finally
            {
                if (cn.State == System.Data.ConnectionState.Open)
                    cn.Close();
            }
            
        }

        public void UtilizeState(object state)
        {
            throw new NotImplementedException();
        }
    }
}
