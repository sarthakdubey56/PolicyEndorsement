﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Entities;
using Exceptions;
using PolicyBusinessLayer;

namespace SwitcherUI
{
    /// <summary>
    /// Interaction logic for ViewPolicy.xaml
    /// </summary>
    public partial class ViewPolicy : UserControl, ISwitchable
    {
        PolicyBL polBL = new PolicyBL();

        CompleteDetails objDetails = null;

        public ViewPolicy()
        {
            InitializeComponent();
                    }

        //public void PopulateUI()
        //{
        //    try
        //    {
        //        IEnumerable<CompleteDetails> details = polBL.SelectBL();
        //        comboName.ItemsSource = prods;
        //        comboName.DisplayMemberPath = "ProdName";

        //    }
        //    catch (Exception ex)
        //    {

        //        MessageBox.Show(ex.Message);
        //        throw;
        //    }
        //}

        public void UtilizeState(object state)
        {
            throw new NotImplementedException();
        }

        private void btnUpdate_Click(object sender, RoutedEventArgs e)
        {
            //try
            //{
            //    cmd = new SqlCommand("PolicyEn.updateCustomer", cn);
            //    cmd.CommandType = System.Data.CommandType.StoredProcedure;
            //    cmd.Parameters.AddWithValue("@polno", txtPolicyNumber.Text);
            //    cmd.Parameters.AddWithValue("@cname", txtCustomerName.Text);
            //    cmd.Parameters.AddWithValue("@cdob", Convert.ToDateTime(txtDateOfBirth.Text));
            //    cmd.Parameters.AddWithValue("@cgen", txtGender.Text);
            //    cmd.Parameters.AddWithValue("@nom ", txtNominee.Text);
            //    cmd.Parameters.AddWithValue("@rel", txtRelation.Text);
            //    cmd.Parameters.AddWithValue("@csmoke", txtSmoker.Text);
            //    cmd.Parameters.AddWithValue("@cadd", txtAddress.Text);
            //    cmd.Parameters.AddWithValue("@cphno", txtPhoneNo.Text);
            //    cmd.Parameters.AddWithValue("@premium", txtPaymentFreq.Text);

            //    cn.Open();
            //    cmd.ExecuteNonQuery();
            //    MessageBox.Show("Records are Successfully Updated");
            //}
            //catch (Exception)
            //{
            //    throw;
            //}
            //finally
            //{
            //    if (cn.State == System.Data.ConnectionState.Open)
            //        cn.Close();
            //}
        }

        private void btnStatus_Click(object sender, RoutedEventArgs e)
        {
            Switcher.Switch(new EndorsementStatus());
        }

        private void btnBrowse_Click(object sender, RoutedEventArgs e)
        {

        }

        private void btnUploadDoc_Click(object sender, RoutedEventArgs e)
        {

        }
    }
}
