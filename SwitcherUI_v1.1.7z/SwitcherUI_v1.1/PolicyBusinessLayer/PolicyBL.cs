﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using PolicyDataAccessLayer;
using Entities;
using Exceptions;

namespace PolicyBusinessLayer
{
    public class PolicyBL
    {
        public IEnumerable<CompleteDetails> ViewDetailsBL()
        {
            IEnumerable<CompleteDetails> objDetails = null;
            try
            {

                PolicyDAL polDL = new PolicyDAL();
                objDetails = polDL.SelectDAL();

            }
            catch (Exception)
            {
                throw;
            }

            return objDetails;
        }

        public IEnumerable<CompleteDetails> SelectBL()
        {
            IEnumerable<CompleteDetails> objDetails = null;
            try
            {

                PolicyDAL polDL = new PolicyDAL();
                objDetails = polDL.SelectDAL();

            }
            catch (Exception)
            {
                throw;
            }

            return objDetails;
        }
    }
}
