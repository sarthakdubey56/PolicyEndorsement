﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Entities;
using Exceptions;
using System.Data.SqlClient;
using System.Configuration;

namespace PolicyDataAccessLayer
{
    public class PolicyDAL
    {
        SqlConnection cn = null;

        SqlCommand cmd = null;

        SqlDataReader dr = null;

        public PolicyDAL()
        {
            cn = new SqlConnection(ConfigurationManager.ConnectionStrings["con"].ConnectionString);
        }

        public IEnumerable<CompleteDetails> ViewDetailsDAL()
        {
            List<CompleteDetails> objDetails = new List<CompleteDetails>();
            
            try
            {
                cmd = new SqlCommand("PolicyEn.selectDetails 1005", cn);
                cn.Open();
                dr = cmd.ExecuteReader();
                if (dr.HasRows)
                {
                    while (dr.Read())
                    {
                        CompleteDetails cd = new CompleteDetails();

                        cd.PolicyNumber = Convert.ToInt32(dr[0]);
                        cd.ProductName = dr[1].ToString();
                        cd.ProductLine = dr[2].ToString();
                        cd.CustomerName = dr[3].ToString();
                        cd.CustAddress = dr[4].ToString();
                        cd.CustPhoneNo = dr[5].ToString();
                        cd.CustomerGender = Convert.ToChar(dr[6]);
                        cd.CustDOB = Convert.ToDateTime(dr[7]);
                        cd.CustSmoker = dr[8].ToString();
                        cd.Nominee = dr[10].ToString();
                        cd.Relation = dr[11].ToString();
                        cd.PremiumPayFrequency = dr[12].ToString();
                        cd.Age = Convert.ToInt32(dr[13]);
                        objDetails.Add(cd);
                    }
                }
                dr.Close();

            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                if (cn.State == System.Data.ConnectionState.Open)
                    cn.Close();
            }
            return objDetails;
        }

        public IEnumerable<CompleteDetails> SelectDAL()
        {
            List<CompleteDetails> objDetails = new List<CompleteDetails>();

            try
            {
                cmd = new SqlCommand("select * from PolicyEn.Customers", cn);
                cn.Open();
                dr = cmd.ExecuteReader();
                if (dr.HasRows)
                {
                    while (dr.Read())
                    {
                        CompleteDetails cd = new CompleteDetails();

                        //cd.PolicyNumber = Convert.ToInt32(dr[0]);
                        //cd.ProductName = dr[1].ToString();
                        //cd.ProductLine = dr[2].ToString();
                        cd.CustomerName = dr[1].ToString();
                        cd.CustAddress = dr[2].ToString();
                        cd.CustPhoneNo = dr[3].ToString();
                        cd.CustomerGender = Convert.ToChar(dr[4]);
                        cd.CustDOB = Convert.ToDateTime(dr[5]);
                        cd.CustSmoker = dr[6].ToString();
                        cd.Nominee = dr[8].ToString();
                        cd.Relation = dr[9].ToString();
                        cd.PremiumPayFrequency = dr[10].ToString();
                        cd.Age = Convert.ToInt32(dr[11]);
                        objDetails.Add(cd);
                    }
                }
                dr.Close();

            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                if (cn.State == System.Data.ConnectionState.Open)
                    cn.Close();
            }
            return objDetails;
        }

        
    }
}
