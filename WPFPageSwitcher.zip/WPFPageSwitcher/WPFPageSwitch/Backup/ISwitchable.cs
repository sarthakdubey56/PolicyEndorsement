﻿
namespace JagoanFisika
{
  	public interface ISwitchable
  	{
    	void UtilizeState( object state );
  	}
}
