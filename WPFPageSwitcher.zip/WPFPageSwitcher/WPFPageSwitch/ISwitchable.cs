﻿
namespace WPFPageSwitch
{
  	public interface ISwitchable
  	{
    	void UtilizeState( object state );
  	}
}
