﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Data;
using System.Data.SqlClient;
using System.Text.RegularExpressions;

namespace PolicyEndorsement.PresentationLayer
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        HomePage home = new HomePage();

        private String ConnectionString;
        private SqlConnection connection;
        private SqlCommand cmd = new SqlCommand();
        private SqlDataReader reader;

        public MainWindow()
        {
            InitializeComponent();

            ConnectionString = @"Data Source=NDAMSSQL\SQLILEARN;Initial Catalog=Training_24Oct18_Pune;Persist Security Info=True;User ID=sqluser;Password=sqluser";
            connection = new SqlConnection(ConnectionString);
        }

        private void BtnLogin_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                int loginId = Convert.ToInt32(txtLoginId.Text);
                string password = txtPassword.Password;


                cmd.CommandText = "Select * from PolicyEn.[Login] "
                            + "where LoginId = '" + loginId + "' "
                            + "and passwd = '" + password + "'";

                cmd.CommandType = CommandType.Text;
                cmd.Connection = connection;
                connection.Open();
                reader = cmd.ExecuteReader();

                int i = 0;

                while (reader.Read())
                {
                    i++;
                }


                if (i == 1)
                {
                    home.Show();
                    Close();
                }
                else
                {
                    MessageBox.Show("INCORRECT PASSWORD OR USER ID", "Authentication Failed");
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Catch Block = " + ex);
            }
            finally
            {
                connection.Close();
            }
            
            }
        }
    }

