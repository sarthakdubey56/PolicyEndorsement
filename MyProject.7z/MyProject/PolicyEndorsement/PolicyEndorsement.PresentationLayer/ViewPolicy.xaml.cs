﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Data.SqlClient;
using System.Configuration;

namespace PolicyEndorsement.PresentationLayer
{
    /// <summary>
    /// Interaction logic for ViewPolicy.xaml
    /// </summary>
    public partial class ViewPolicy : Window
    {
        EndorsementStatus status = new EndorsementStatus();

        public ViewPolicy()
        {
            InitializeComponent();

        }

        private void BtnStatus_Click(object sender, RoutedEventArgs e)
        {
            //status.Show();
            //Close();
        }

        public void PopulateUI()
        {

        }

        private void BtnUpdate_Click(object sender, RoutedEventArgs e)
        {
            SqlConnection cn = null;

            SqlCommand cmd = null;
            
            try
            {
                cmd = new SqlCommand("PolicyEn.updateCustomer", cn);
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@cname", txtCustomerName.Text);
                cmd.Parameters.AddWithValue("@cdob", Convert.ToDateTime(txtDateOfBirth.Text));
                cmd.Parameters.AddWithValue("@cgen", txtGender.Text);
                cmd.Parameters.AddWithValue("@nom ", txtNominee.Text);
                cmd.Parameters.AddWithValue("@rel", txtRelation.Text);
                cmd.Parameters.AddWithValue("@csmoke", txtSmoker.Text);
                cmd.Parameters.AddWithValue("@cadd", txtAddress.Text);
                cmd.Parameters.AddWithValue("@cphno", txtPhoneNo.Text);
                cmd.Parameters.AddWithValue("@premium", txtPaymentFreq.Text);
                cn.Open();
                cmd.ExecuteNonQuery();
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                if (cn.State == System.Data.ConnectionState.Open)
                    cn.Close();
            }
        }
    }
}
