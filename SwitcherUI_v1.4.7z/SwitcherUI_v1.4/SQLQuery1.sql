﻿create table PolicyEn.AllDocuments(
PolicyNo INT,
[FileName] varchar(MAX)
foreign key(PolicyNo) REFERENCES PolicyEn.[Policy](PolicyNumber)
)

select * from PolicyEn.AllDocuments

select * from PolicyEn.Customers
select * from PolicyEn.[Policy]

select * from airline.FlightClass

insert into PolicyEn.AllDocuments values(100004, 'gksjfabsdfzbsdfnbestdnbdjv'),
(100004, 'jhfkgijvugfdxnxfgdnfghleksjfh');

drop table PolicyEn.AllDocuments

ALTER PROCEDURE [PolicyEn].updateCustomer
@cname VARCHAR(50),
@cdob DATE,
@cgen VARCHAR(50),
@nom VARCHAR(50),
@rel VARCHAR(50),
@csmoke VARCHAR(50),
@cadd VARCHAR(50),
@cphno VARCHAR(50),
@premium VARCHAR(50),


@Ocadd VARCHAR(50),
@polno INT
AS
Begin
	Select  
	@Ocadd = CustAddress
	from [PolicyEn].[Customers]WHERE P1.PolicyNumber = @polno;

	  UPDATE [PolicyEn].[Customers] SET Age = DATEDIFF(year,@cdob,GETDATE())  FROM [PolicyEn].[Customers] C1 INNER JOIN  [PolicyEn].[Policy] P1 ON (C1.CustId = P1.CustId) WHERE P1.PolicyNumber IN (@polno);
      UPDATE [PolicyEn].[Customers] SET CustName=@cname,Smoker=@csmoke,DOB=@cdob,CustAddress=@cadd,CustPhoneNo=@cphno,CustGender=@cgen,Relation=@rel,Nominee=@nom,Premium_payment_freq=@premium  FROM [PolicyEn].[Customers] C1 INNER JOIN  [PolicyEn].[Policy] P1 ON (C1.CustId = P1.CustId)WHERE P1.PolicyNumber IN (@polno);

	  if @Ocadd != @cadd
	  Begin
		Insert into PolicyEn.[Status] values (@polno,@cadd,'approved');
	  End
End


Create table PolicyEn.[Status](
policyNo int,
fields varchar(50),
[status] varchar(20),
foreign Key(policyNo) REFERENCES PolicyEn.[Policy](PolicyNumber)
);

select * from PolicyEn.[Status]


ALTER PROCEDURE [PolicyEn].updateCustomer
@cname VARCHAR(50),
@cdob DATE,
@cgen VARCHAR(50),
@nom VARCHAR(50),
@rel VARCHAR(50),
@csmoke VARCHAR(50),
@cadd VARCHAR(50),
@cphno VARCHAR(50),
@premium VARCHAR(50),

--@Ocname VARCHAR(50),
--@Ocdob DATE,
--@Ocgen VARCHAR(50),
--@Onom VARCHAR(50),
--@Orel VARCHAR(50),
--@Ocsmoke VARCHAR(50),

--@Ocphno VARCHAR(50),
--@Opremium VARCHAR(50),
@Ocadd VARCHAR(50),
@polno INT 
AS
Begin
	Set @Ocadd = (Select C.CustAddress
	from [PolicyEn].[Customers] C inner join [PolicyEn].[Policy] P on c.CustId = P.CustId where P.PolicyNumber = 100003);
  
	  UPDATE [PolicyEn].[Customers] SET Age = DATEDIFF(year,@cdob,GETDATE())  FROM [PolicyEn].[Customers] C1 
									INNER JOIN  [PolicyEn].[Policy] P1 ON (C1.CustId = P1.CustId) 
									WHERE P1.PolicyNumber IN (@polno);
      UPDATE [PolicyEn].[Customers] SET CustName=@cname,Smoker=@csmoke,DOB=@cdob,CustAddress=@cadd,
									CustPhoneNo=@cphno,CustGender=@cgen,Relation=@rel,Nominee=@nom,
									Premium_payment_freq=@premium  FROM [PolicyEn].[Customers] C1 
									INNER JOIN  [PolicyEn].[Policy] P1 ON (C1.CustId = P1.CustId)
									WHERE P1.PolicyNumber IN (@polno);

	  If @Ocadd != @cadd
	  Begin
		Insert into PolicyEn.[Status] values (@polno,@cadd,'approved');
	  End
End  







Alter procedure asdf
@Ocadd varchar(50)
as

	Set @Ocadd = (Select C.CustAddress
	from [PolicyEn].[Customers] C inner join [PolicyEn].[Policy] P on c.CustId = P.CustId where P.PolicyNumber = 100003);

drop proc asdf