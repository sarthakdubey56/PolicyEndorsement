﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Entities;
using Exceptions;
using PolicyBusinessLayer;

using System.IO;
using Microsoft.Win32;

namespace SwitcherUI
{
    /// <summary>
    /// Interaction logic for ViewPolicy.xaml
    /// </summary>
    public partial class ViewPolicy : UserControl, ISwitchable
    {
        static PolicyBL polBL = new PolicyBL();

        CompleteDetails objDetails = new CompleteDetails();

        IEnumerable<Document> file = polBL.SelectDocBL();

        public ViewPolicy(CompleteDetails sel)
        {
            InitializeComponent();
            PopulateUI(sel);
            dgFileName.ItemsSource = file;
        }

        public void PopulateUI(CompleteDetails sel)
        {
            try
            {
                txtPolicyNumber.Text = sel.PolicyNumber.ToString();
                txtProductLine.Text = sel.ProductLine.ToString();
                txtProductName.Text = sel.ProductName.ToString();
                txtCustomerName.Text = sel.CustomerName.ToString();
                txtCustomerAge.Text = sel.Age.ToString();
                txtDateOfBirth.Text = sel.CustDOB.ToString();
                txtGender.Text = sel.CustomerGender.ToString();
                txtNominee.Text = sel.Nominee.ToString();
                txtRelation.Text = sel.Relation.ToString();
                txtSmoker.Text = sel.CustSmoker.ToString();
                txtAddress.Text = sel.CustAddress.ToString();
                txtPhoneNo.Text = sel.CustPhoneNo.ToString();
                txtPaymentFreq.Text = sel.PremiumPayFrequency.ToString();
               polBL.ViewDetailsBL(sel);
            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message);
                throw;
            }
        }

        public void UtilizeState(object state)
        {
            throw new NotImplementedException();
        }

        private void btnUpdate_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                CompleteDetails objDetails = new CompleteDetails
                {
                    PolicyNumber = Convert.ToInt32(txtPolicyNumber.Text),
                    ProductLine = txtProductLine.Text,
                    ProductName = txtProductName.Text,
                    CustomerName = txtCustomerName.Text,
                    Age = Convert.ToInt32(txtCustomerAge.Text),
                    CustDOB = Convert.ToDateTime(txtDateOfBirth.Text),
                    CustomerGender = Convert.ToChar(txtGender.Text),
                    Nominee = txtNominee.Text,
                    Relation = txtRelation.Text,
                    CustSmoker = txtSmoker.Text,
                    CustAddress = txtAddress.Text,
                    CustPhoneNo = txtPhoneNo.Text,
                    PremiumPayFrequency = txtPaymentFreq.Text
                };
                polBL.UpdateBL(objDetails);
                MessageBox.Show("Update Succesfully");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                throw;
            }
        }

        private void btnStatus_Click(object sender, RoutedEventArgs e)
        {
            Switcher.Switch(new EndorsementStatus());
        }

        private void btnBrowse_Click(object sender, RoutedEventArgs e)
        {

        }

        private void btnUploadDoc_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                Stream checkStream = null;
                OpenFileDialog dlg = new OpenFileDialog();
                dlg.Multiselect = true;
                dlg.Filter = "All Image Files | *.*";
                Nullable<bool> result = dlg.ShowDialog();
                if (result == true)
                {
                    try
                    {
                        if ((checkStream = dlg.OpenFile()) != null)
                        {
                            var filename = dlg.FileName;
                            polBL.UploadBL(filename);
                            dgFileName.ItemsSource = file;

                            MessageBox.Show("Successfully done", filename);
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Error: Could not read file from disk. Original error: " + ex.Message);
                    }

                }
                else
                {

                    MessageBox.Show("Problem occured, try again later");

                }
            }
            catch (Exception)
            {
                throw;
            }
        }

        private void BtnSearch_Click(object sender, RoutedEventArgs e)
        {
            Switcher.Switch(new SearchPolicy());
        }
    }
}
