﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PolicyEndorsement.Entities
{
    public class CompleteDetails
    {
        public int PolicyNumber { get; set; }

        public string ProductName { get; set; }
        public string ProductLine { get; set; }

        public int CustomerId { get; set; }
        public string CustomerName { get; set; }
        public int Age { get; set; }
        public DateTime CustDOB { get; set; }
        public char CustomerGender { get; set; }
        public string Nominee { get; set; }
        public string Relation { get; set; }
        public string CustSmoker { get; set; }
        public string CustAddress { get; set; }
        public string CustPhoneNo { get; set; }
        public string PremiumPayFrequency { get; set; }

        public CompleteDetails()
        {

        }
    }
}
