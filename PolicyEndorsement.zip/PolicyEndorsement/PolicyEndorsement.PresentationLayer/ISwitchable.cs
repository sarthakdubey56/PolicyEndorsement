﻿namespace PolicyEndorsement.PresentationLayer
{
    interface ISwitchable
    {
        void UtilizeState(object state);
    }
}
