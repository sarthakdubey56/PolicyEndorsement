﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PolicyEndorsement.Entities
{
    public class Endorsement
    {
        //Endorsement entities
        public int EndorsemntId{ get; set; }
        public string EndorsemntType{ get; set; }
        public DateTime ExpiryDate{ get; set; }
        public int PolicyNumber{ get; set; }

        //Endorsement Constructor
        public Endorsement()
        {

        }
    }
}
