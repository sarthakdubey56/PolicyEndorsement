﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PolicyEndorsement.Entities
{
    public class Login
    {
        //Login entities
        public int CustomerId { get; set; }
        public int LoginId { get; set; }
        public string Password { get; set; }

        //Login Constructor
        public Login()
        {

        }
    }
}
