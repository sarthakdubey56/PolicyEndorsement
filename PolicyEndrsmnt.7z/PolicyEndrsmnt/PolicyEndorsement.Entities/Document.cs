﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PolicyEndorsement.Entities
{
    public class Document
    {
        //Document entities
        public int DocumentId { get; set; }
        public string DocumentName { get; set; }
        public int EndorsementId { get; set; }

        //Document Constructor
        public Document()
        {

        }
    }
}
