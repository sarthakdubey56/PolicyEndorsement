﻿select * from PolicyEn.Products
select * from PolicyEn.[Policy]
select * from PolicyEn.Customers
select * from PolicyEn.Documents
select * from PolicyEn.[Login]
select * from PolicyEn.Endorsement