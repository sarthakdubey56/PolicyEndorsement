﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace PolicyEndrsmnt
{
    /// <summary>
    /// Interaction logic for ViewPolicy.xaml
    /// </summary>
    public partial class ViewPolicy : Window
    {
        EndorsementStatus status = new EndorsementStatus();

        public ViewPolicy()
        {
            InitializeComponent();
        }

        private void BtnStatus_Click(object sender, RoutedEventArgs e)
        {
            status.Show();
        }
    }
}
