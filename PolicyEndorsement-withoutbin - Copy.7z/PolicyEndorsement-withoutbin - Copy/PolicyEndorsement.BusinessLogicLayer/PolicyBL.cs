﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using PolicyEndorsement.Exceptions;
using PolicyEndorsement.Entities;
using PolicyEndorsement.DataAccessLayer;
using System.Text.RegularExpressions;

namespace PolicyEndorsement.BusinessLogicLayer
{
    public class PolicyBL
    {

        private static bool ValidatePol(Customer customer)
        {
            StringBuilder sb = new StringBuilder();

            bool validPol = true;

            if (!Regex.IsMatch(customer.CustomerName, "^[a-zA-Z]+$"))
            {
                validPol = false;
                sb.Append(Environment.NewLine + "Customer name should be accept only alphabets:");
            }
            if (!Regex.IsMatch(customer.Nominee, "^[a-zA-Z]+$"))
            {
                validPol = false;
                sb.Append(Environment.NewLine + "Nominee should be accept only alphabets:");
            }
            if (!Regex.IsMatch(customer.CustPhoneNo, "^[0-9]+$"))
            {
                validPol = false;
                sb.Append(Environment.NewLine + "Phone number should except only number");
            }


            if (customer.Age < 18)
            {
                validPol = false;
                sb.Append(Environment.NewLine + "Age should be above 18 years");
            }


            if (customer.CustPhoneNo.ToString().Length != 10)
            {
                validPol = false;
                sb.Append(Environment.NewLine + "Phone number must have exactly 10 digits");
            }

            if (validPol == false)
            {
                throw new PolicyException(sb.ToString());
            }

            return validPol;
        }

        private static bool ValidatePassword(UserLogin login)
        {
            bool isValid = true;

            StringBuilder sb = new StringBuilder();

            if (!Regex.IsMatch(login.Password, @"^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[^\da-zA-Z]).{8,15}$"))
            {
                isValid = false;
                sb.Append(Environment.NewLine + "Password should contain atleast one lowercase letter,one uppercase letter,one number and one special character");
            }
            if (isValid == false)
            {
                throw new PolicyException(sb.ToString());
            }
            return isValid;
        }



        public IEnumerable<CompleteDetails> ViewDetailsBL(CompleteDetails customer)
        {
            IEnumerable<CompleteDetails> objDetails = null;
            try
            {
                PolicyDAL polDAL = new PolicyDAL();
                objDetails = polDAL.ViewDetailsDAL(customer);
            }
            catch (Exception)
            {
                throw;
            }
            return objDetails;
        }

        public IEnumerable<CompleteDetails> SelectBL()
        {
            IEnumerable<CompleteDetails> objDetails = null;
            try
            {
                PolicyDAL polDAL = new PolicyDAL();
                objDetails = polDAL.SelectDAL();
            }
            catch (Exception)
            {
                throw;
            }

            return objDetails;
        }

        public bool UpdateBL(Customer customer, Product product, Policy policy)
        {
            bool isUpdated = false;
            try
            {
                if (ValidatePol(customer))
                {
                    PolicyDAL polDAL = new PolicyDAL();
                    isUpdated = polDAL.UpdateDAL(customer, policy);
                }

            }
            catch (PolicyException)
            {
                throw;
            }
            catch (Exception)
            {
                throw;
            }
            return isUpdated;
        }

        public bool UploadBL(int pol, string file)
        {
            bool filename = false;
            try
            {
                PolicyDAL polDAL = new PolicyDAL();
                filename = polDAL.UploadDAL(pol, file);
            }
            catch (Exception)
            {
                throw;
            }
            return filename;
        }


        public IEnumerable<Document> SelectDocBL()
        {
            IEnumerable<Document> objFile = null;
            try
            {
                PolicyDAL polDAL = new PolicyDAL();
                objFile = polDAL.SelectDocDAL();
            }
            catch (Exception)
            {
                throw;
            }

            return objFile;
        }

        public IEnumerable<EndorsementStatus> SelectUpdateDetailsBL()
        {
            IEnumerable<EndorsementStatus> objStatus = null;
            try
            {
                PolicyDAL polDAL = new PolicyDAL();
                objStatus = polDAL.SelectUpdateDetailsDAL();
            }
            catch (Exception)
            {
                throw;
            }

            return objStatus;
        }

        public bool LoginBL(UserLogin login)
        {
            bool filename = false;
            try
            {
                if (ValidatePassword(login))
                {
                    PolicyDAL polDAL = new PolicyDAL();
                    filename = polDAL.LoginDAL(login);
                }


            }
            catch (Exception)
            {
                throw;
            }
            return filename;
        }
    }
}
