﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PolicyEndorsement.Entities
{
    public class Product
    {
        //Product Entities
        public int ProductId { get; set; }
        public string ProductName { get; set; }
        public string ProductLine { get; set; }
        public string ProdDescription { get; set; }
        public string ProdCategory { get; set; }

        //Product Constructor
        public Product()
        {

        }
    }
}
