﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using PolicyDataAccessLayer;
using Entities;
using Exceptions;

namespace PolicyBusinessLayer
{
    public class PolicyBL
    {
        public IEnumerable<CompleteDetails> ViewDetailsBL(CompleteDetails sel)
        {
            IEnumerable<CompleteDetails> objDetails = null;
            try
            {

                PolicyDAL polDAL = new PolicyDAL();
                objDetails = polDAL.ViewDetailsDAL(sel);

            }
            catch (Exception)
            {
                throw;
            }

            return objDetails;
        }

        public IEnumerable<CompleteDetails> SelectBL()
        {
            IEnumerable<CompleteDetails> objDetails = null;
            try
            {

                PolicyDAL polDAL = new PolicyDAL();
                objDetails = polDAL.SelectDAL();

            }
            catch (Exception)
            {
                throw;
            }

            return objDetails;
        }

        public bool UpdateBL(CompleteDetails sel)
        {
            bool isUpdated = false;
            try
            {
                    PolicyDAL polDAL = new PolicyDAL();
                    isUpdated = polDAL.UpdateDAL(sel);

            }
            catch (Exception)
            {
                throw;
            }
            return isUpdated;
        }
    }
}
