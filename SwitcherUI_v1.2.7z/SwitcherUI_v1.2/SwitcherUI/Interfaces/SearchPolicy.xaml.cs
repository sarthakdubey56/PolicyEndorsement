﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Entities;
using Exceptions;
using PolicyBusinessLayer;

namespace SwitcherUI
{ 
    /// <summary>
    /// Interaction logic for SearchPolicy.xaml
    /// </summary>
    /// 
    public partial class SearchPolicy : UserControl, ISwitchable
    {
        static PolicyBL polBL = new PolicyBL();

        static CompleteDetails objDetails = new CompleteDetails();

        

        public SearchPolicy()
        {
            InitializeComponent();

            dgSearchResults.ItemsSource = details;

            PopulateUI();
        }

        IEnumerable<CompleteDetails> details = polBL.SelectBL();
        

        public void PopulateUI()
        {
            try
            {
                cmbBoxSearchPolNum.ItemsSource = details;
                cmbBoxSearchPolNum.DisplayMemberPath = "PolicyNumber";
                cmbBoxSearchCustID.ItemsSource = details;
                cmbBoxSearchCustID.DisplayMemberPath = "CustomerId";
                cmbBoxSearchName.ItemsSource = details;
                cmbBoxSearchName.DisplayMemberPath = "CustomerName";

            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message);
                throw;
            }
        }

        public void UtilizeState(object state)
        {
            throw new NotImplementedException();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            Switcher.Switch(new HomePage());
        }

        #region SearchBox Event Handlers
        private void ComboBoxItem_Selected_NameDOB(object sender, RoutedEventArgs e)
        {
            datePkrDOB.Visibility = Visibility.Visible;
            lblSearchDOB.Visibility = Visibility.Visible;
            cmbBoxSearchName.Visibility = Visibility.Visible;
            lblSearchName.Visibility = Visibility.Visible;

            datePkrDOB.IsEnabled = true;
            lblSearchDOB.IsEnabled = true;
            cmbBoxSearchName.IsEnabled = true;
            lblSearchName.IsEnabled = true;
        }

        private void ComboBoxItem_Unselected_NameDOB(object sender, RoutedEventArgs e)
        {
            datePkrDOB.Visibility = Visibility.Hidden;
            lblSearchDOB.Visibility = Visibility.Hidden;
            cmbBoxSearchName.Visibility = Visibility.Hidden;
            lblSearchName.Visibility = Visibility.Hidden;

            datePkrDOB.IsEnabled = false;
            lblSearchDOB.IsEnabled = false;
            cmbBoxSearchName.IsEnabled = false;
            lblSearchName.IsEnabled = false;
        }

        private void ComboBoxItem_Selected_PolNum(object sender, RoutedEventArgs e)
        {
            cmbBoxSearchPolNum.Visibility = Visibility.Visible;
            lblSearchPolNum.Visibility = Visibility.Visible;

            cmbBoxSearchPolNum.IsEnabled = true;
            lblSearchPolNum.IsEnabled = true;
        }

        private void ComboBoxItem_Unselected_PolNum(object sender, RoutedEventArgs e)
        {
            cmbBoxSearchPolNum.Visibility = Visibility.Hidden;
            lblSearchPolNum.Visibility = Visibility.Hidden;

            cmbBoxSearchPolNum.IsEnabled = false;
            lblSearchPolNum.IsEnabled = false;
        }

        private void ComboBoxItem_Selected_CustID(object sender, RoutedEventArgs e)
        {
            cmbBoxSearchCustID.Visibility = Visibility.Visible;
            lblSearchCustID.Visibility = Visibility.Visible;

            cmbBoxSearchCustID.IsEnabled = true;
            lblSearchCustID.IsEnabled = true;
        }

        private void ComboBoxItem_Unselected_CustID(object sender, RoutedEventArgs e)
        {
            cmbBoxSearchCustID.Visibility = Visibility.Hidden;
            lblSearchCustID.Visibility = Visibility.Hidden;

            cmbBoxSearchCustID.IsEnabled = false;
            lblSearchCustID.IsEnabled = false;
        }
        #endregion

        private void CmbBoxSearchPolNum_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
                var res = details.Where(s => s.PolicyNumber == Convert.ToInt32(cmbBoxSearchPolNum.Text));
                dgSearchResults.ItemsSource = res;
        }

        private void CmbBoxSearchCustID_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            var res = details.Where(s => s.CustomerId == Convert.ToInt32(cmbBoxSearchCustID.Text));
            dgSearchResults.ItemsSource = res;
        }

        private void CmbBoxSearchName_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            var res = details.Where(s => s.CustomerName == cmbBoxSearchName.Text.ToString() & s.CustDOB == Convert.ToDateTime(datePkrDOB.Text));
            dgSearchResults.ItemsSource = res;
        }

        private void DgSearchResults_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            if (dgSearchResults.SelectedItem == null)
            {
                return;
            }
            CompleteDetails selectedPopulation = dgSearchResults.SelectedItem as CompleteDetails;
            
             Switcher.Switch(new ViewPolicy(selectedPopulation));
        }
    }
}
