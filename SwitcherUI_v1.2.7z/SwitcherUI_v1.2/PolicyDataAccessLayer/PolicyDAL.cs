﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Entities;
using Exceptions;
using System.Data.SqlClient;
using System.Configuration;

namespace PolicyDataAccessLayer
{
    public class PolicyDAL
    {
        SqlConnection cn = null;

        SqlCommand cmd = null;

        SqlDataReader dr = null;

        static List<CompleteDetails> objDetails = new List<CompleteDetails>();

        public PolicyDAL()
        {
            cn = new SqlConnection(ConfigurationManager.ConnectionStrings["con"].ConnectionString);
        }

        public IEnumerable<CompleteDetails> ViewDetailsDAL(CompleteDetails sel)
        {
            
            try
            {
                cmd = new SqlCommand("PolicyEn.selectDetails @cID", cn);
                cmd.Parameters.AddWithValue("@cID", sel.CustomerId);
                cn.Open();
                dr = cmd.ExecuteReader();
                if (dr.HasRows)
                {
                    while (dr.Read())
                    {
                        CompleteDetails cd = new CompleteDetails();

                        cd.PolicyNumber = Convert.ToInt32(dr[0]);
                        cd.ProductName = dr[1].ToString();
                        cd.ProductLine = dr[2].ToString();
                        cd.CustomerName = dr[3].ToString();
                        cd.CustAddress = dr[4].ToString();
                        cd.CustPhoneNo = dr[5].ToString();
                        cd.CustomerGender = Convert.ToChar(dr[6]);
                        cd.CustDOB = Convert.ToDateTime(dr[7]);
                        cd.CustSmoker = dr[8].ToString();
                        cd.Nominee = dr[10].ToString();
                        cd.Relation = dr[11].ToString();
                        cd.PremiumPayFrequency = dr[12].ToString();
                        cd.Age = Convert.ToInt32(dr[13]);
                        objDetails.Add(cd);
                    }
                }
                dr.Close();

            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                if (cn.State == System.Data.ConnectionState.Open)
                    cn.Close();
            }
            return objDetails;
        }

        public IEnumerable<CompleteDetails> SelectDAL()
        {

            try
            {
                cmd = new SqlCommand("PolicyEn.SelectAll", cn);
                cn.Open();
                dr = cmd.ExecuteReader();
                if (dr.HasRows)
                {
                    while (dr.Read())
                    {
                        CompleteDetails cd = new CompleteDetails();

                        cd.PolicyNumber = Convert.ToInt32(dr[0]);
                        cd.ProductLine = dr[1].ToString();
                        cd.ProductName = dr[2].ToString();
                        cd.CustomerId = Convert.ToInt32(dr[3]);
                        cd.CustomerName = dr[4].ToString();
                        cd.Age = Convert.ToInt32(dr[5]);
                        cd.CustDOB = Convert.ToDateTime(dr[6]);
                        cd.CustomerGender = Convert.ToChar(dr[7]);
                        cd.Nominee = dr[8].ToString();
                        cd.Relation = dr[9].ToString();
                        cd.CustSmoker = dr[10].ToString();
                        cd.CustAddress = dr[11].ToString();
                        cd.CustPhoneNo = dr[12].ToString();
                        cd.PremiumPayFrequency = dr[13].ToString();
                        objDetails.Add(cd);
                    }
                }
                dr.Close();

            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                if (cn.State == System.Data.ConnectionState.Open)
                    cn.Close();
            }
            return objDetails;
        }

        public bool UpdateDAL( CompleteDetails sel)
        {
            bool isUpdated = false;
            try
            {
                cmd = new SqlCommand("PolicyEn.updateCustomer", cn);
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@polno", sel.PolicyNumber);
                cmd.Parameters.AddWithValue("@cname", sel.CustomerName);
                cmd.Parameters.AddWithValue("@cdob", sel.CustDOB);
                cmd.Parameters.AddWithValue("@cgen", sel.CustomerGender);
                cmd.Parameters.AddWithValue("@nom ", sel.Nominee);
                cmd.Parameters.AddWithValue("@rel", sel.Relation);
                cmd.Parameters.AddWithValue("@csmoke", sel.CustSmoker);
                cmd.Parameters.AddWithValue("@cadd", sel.CustAddress);
                cmd.Parameters.AddWithValue("@cphno", sel.CustPhoneNo);
                cmd.Parameters.AddWithValue("@premium", sel.PremiumPayFrequency);
                cn.Open();
                cmd.ExecuteNonQuery();
                isUpdated = true;
                
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                if (cn.State == System.Data.ConnectionState.Open)
                    cn.Close();
            }
            return isUpdated;
        }

        
    }
}
