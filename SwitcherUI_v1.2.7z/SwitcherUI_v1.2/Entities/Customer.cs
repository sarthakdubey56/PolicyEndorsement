﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entities
{
    public class Customer
    {
        //Customer entities
        public int CustomerId { get; set; }
        public string CustomerName { get; set; }
        public int Age { get; set; }
        public DateTime CustDOB { get; set; }
        public char CustomerGender { get; set; }
        public string Nominee { get; set; }
        public string Relation { get; set; }
        public string CustSmoker { get; set; }
        public string CustAddress { get; set; }
        public string CustPhoneNo { get; set; }
        public string PremiumPayFrequency { get; set; }
        public string CustHobbies { get; set; }



        //Customer Constructor
        public Customer()
        {

        }
    }
}
