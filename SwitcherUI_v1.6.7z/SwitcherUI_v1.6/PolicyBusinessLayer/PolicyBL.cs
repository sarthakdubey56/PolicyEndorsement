﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using PolicyDataAccessLayer;
using Entities;
using Exceptions;
using System.Text.RegularExpressions;

namespace PolicyBusinessLayer
{
    public class PolicyBL
    {
        private static bool ValidatePol(Customer customer)
        {
            StringBuilder sb = new StringBuilder();

            bool validPol = true;

            if (!Regex.IsMatch(customer.CustomerName, "^[a-zA-Z]+$"))
            {
                validPol = false;
                sb.Append(Environment.NewLine + "Customer name should be accept only alphabets:");
            }
            if (!Regex.IsMatch(customer.Nominee, "^[a-zA-Z]+$"))
            {
                validPol = false;
                sb.Append(Environment.NewLine + "Nominee should be accept only alphabets:");
            }
            if (!Regex.IsMatch(customer.CustPhoneNo, "^[0-9]+$"))
            {
                validPol = false;
                sb.Append(Environment.NewLine + "Phone number should except only number");
            }






            if (customer.CustomerName == string.Empty)
            {
                validPol = false;
                sb.Append(Environment.NewLine + "Customer name should not be empty");
            }
            if (customer.Age < 18)
            {
                validPol = false;
                sb.Append(Environment.NewLine + "Age should be above 18 years");
            }
            if (customer.CustomerGender.ToString() == string.Empty)

            {
                validPol = false;
                sb.Append(Environment.NewLine + "Gender is not Selected");
            }


            if (customer.Nominee == string.Empty)
            {
                validPol = false;
                sb.Append(Environment.NewLine + "Enter Nominee Name");
            }

            if (customer.Relation == string.Empty)
            {
                validPol = false;
                sb.Append(Environment.NewLine + "Enter Your Relation");
            }
            if (customer.CustSmoker == string.Empty)
            {
                validPol = false;
                sb.Append(Environment.NewLine + "Enter weather you are smoker or not smoker");
            }
            if (customer.CustAddress == string.Empty)
            {
                validPol = false;
                sb.Append(Environment.NewLine + "Enter your address");
            }
            if (customer.CustPhoneNo.ToString().Length != 10)
            {
                validPol = false;
                sb.Append(Environment.NewLine + "Phone number must have exactly 10 digits");
            }
            if (customer.PremiumPayFrequency == string.Empty)
            {
                validPol = false;
                sb.Append(Environment.NewLine + "Enter your premium payment frequency like monthly,quaterly and yearly");
            }

            if (validPol == false)
            {
                throw new Policy_Exception(sb.ToString());
            }

            return validPol;
        }




        //public IEnumerable<Customer> ViewCustomerBL(Customer customer)
        //{
        //    IEnumerable<Customer> objCustomer = null;
        //    try
        //    {
        //        PolicyDAL polDAL = new PolicyDAL();
        //        objCustomer = polDAL.ViewCustomerDAL(customer);
        //    }
        //    catch (Policy_Exception ex)
        //    {
        //        throw ex;
        //    }
        //    catch (Exception)
        //    {
        //        throw;
        //    }

        //    return objCustomer;
        //}

        //public IEnumerable<Product> ViewProductBL(Product product, Customer customer)
        //{
        //    IEnumerable<Product> objProduct = null;
        //    try
        //    {
        //        PolicyDAL polDAL = new PolicyDAL();
        //        objProduct = polDAL.ViewProductDAL(product, customer);
        //    }
        //    catch (Policy_Exception ex)
        //    {
        //        throw ex;
        //    }
        //    catch (Exception)
        //    {
        //        throw;
        //    }

        //    return objProduct;
        //}

        //public IEnumerable<Policy> ViewPolicyBL(Policy policy, Customer customer)
        //{
        //    IEnumerable<Policy> objPolicy = null;
        //    try
        //    {
        //        PolicyDAL polDAL = new PolicyDAL();
        //        objPolicy = polDAL.ViewPolicyDAL(policy, customer);
        //    }
        //    catch (Policy_Exception ex)
        //    {
        //        throw ex;
        //    }
        //    catch (Exception)
        //    {
        //        throw;
        //    }

        //    return objPolicy;
        //}



        public IEnumerable<CompleteDetails> ViewDetailsBL(CompleteDetails customer)
        {
            IEnumerable<CompleteDetails> objDetails = null;
            try
            {
                PolicyDAL polDAL = new PolicyDAL();
                objDetails = polDAL.ViewDetailsDAL(customer);
            }
            catch (Policy_Exception ex)
            {
                throw ex;
            }
            catch (Exception)
            {
                throw;
            }

            return objDetails;
        }

        

        public IEnumerable<CompleteDetails> SelectBL()
        {
            IEnumerable<CompleteDetails> objDetails = null;
            try
            {

                PolicyDAL polDAL = new PolicyDAL();
                objDetails = polDAL.SelectDAL();

            }
            catch (Exception)
            {
                throw;
            }

            return objDetails;
        }



//        public IEnumerable<Customer> SelectCustomerBL()
//        {
//            IEnumerable<Customer> objCustomer = null;
//            try
//            {

//                PolicyDAL polDAL = new PolicyDAL();
//                objCustomer = polDAL.SelectCustomerDAL();

//            }
//            catch (Exception)
//            {
//                throw;
//            }

//            return objCustomer;
//        }

//        public IEnumerable<Product> SelectProductBL()
//        {
//            IEnumerable<Product> objProduct = null;
//            try
//            {

//                PolicyDAL polDAL = new PolicyDAL();
//                objProduct = polDAL.SelectProductDAL();

//            }
//            catch (Exception)
//            {
//                throw;
//            }

//            return objProduct
//;
//        }

//        public IEnumerable<Policy> SelectPolicyBL()
//        {
//            IEnumerable<Policy> objPolicy = null;
//            try
//            {

//                PolicyDAL polDAL = new PolicyDAL();
//                objPolicy = polDAL.SelectPolicyDAL();

//            }
//            catch (Exception)
//            {
//                throw;
//            }

//            return objPolicy;
//        }




        public bool UpdateBL(Customer customer, Product product, Policy policy)
        {
            bool isUpdated = false;
            try
            {
                if (ValidatePol(customer))
                {
                    PolicyDAL polDAL = new PolicyDAL();
                    isUpdated = polDAL.UpdateDAL(customer, policy);
                }
                
            }
            catch (Policy_Exception)
            {
                throw;
            }
            catch (Exception)
            {
                throw;
            }
            return isUpdated;
        }

        public bool UploadBL(int pol, string file)
        {
            bool filename = false;
            try
            {
                PolicyDAL polDAL = new PolicyDAL();
                filename = polDAL.UploadDAL(pol, file);

            }
            catch (Exception)
            {
                throw;
            }
            return filename;
        }


        public IEnumerable<Document> SelectDocBL()
        {
            IEnumerable<Document> objFile = null;
            try
            {

                PolicyDAL polDAL = new PolicyDAL();
                objFile = polDAL.SelectDocDAL();

            }
            catch (Exception)
            {
                throw;
            }

            return objFile;
        }

        public IEnumerable<EndorsStatus> SelectUpdateDetailsBL()
        {
            IEnumerable<EndorsStatus> objStatus = null;
            try
            {
                    PolicyDAL polDAL = new PolicyDAL();
                    objStatus = polDAL.SelectUpdateDetailsDAL();
            }
            catch (Exception)
            {
                throw;
            }

            return objStatus;
        }
    }
}
