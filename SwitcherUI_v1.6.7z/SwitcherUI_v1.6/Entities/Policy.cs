﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entities
{
    public class Policy
    {
        //Policy Table
        public int PolicyNumber { get; set; }
        public int CustomerId { get; set; }
        public int ProductId { get; set; }

        //Policy Constructor
        public Policy()
        {

        }
    }
}
