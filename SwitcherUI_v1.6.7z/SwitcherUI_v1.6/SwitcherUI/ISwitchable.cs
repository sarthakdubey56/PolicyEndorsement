﻿namespace SwitcherUI
{
    public interface ISwitchable
    {
        void UtilizeState(object state);
    }
}
