SELECT * FROM  [PolicyEn].[Products];
SELECT * FROM  [PolicyEn].[Policy];

INSERT INTO  [PolicyEn].[Policy] VALUES (1003,3);

SELECT CustId, LoginId, Passwd FROM  [PolicyEn].[Login] where LoginId = 1000 and Passwd = 'Umang123';


INSERT INTO  [PolicyEn].[Login] VALUES ('Shariq123',1004),('Siddhesh23',1008);

DROP TABLE  [PolicyEn].[Login]

CREATE TABLE [PolicyEn].[Login]
(
LoginId INT CONSTRAINT pk_Log PRIMARY KEY IDENTITY(1000,1),
Passwd VARCHAR(50),
CustId INT,
FOREIGN KEY(CustId) REFERENCES [PolicyEn].[Customers](CustId)
)


SELECT * FROM  [PolicyEn].[Endorsement];

SELECT * FROM  [PolicyEn].[Documents];

SELECT * FROM [PolicyEn].[Customers];

Select * from PolicyEn.[Login]

Select * from PolicyEn.Products

INSERT INTO [PolicyEn].[Products] VALUES('Wagonar','Nice Average','Truck','Life');


ALTER Procedure [PolicyEn].[SelectAll]
as
SELECT 
	P.PolicyNumber,
	D.ProductLine,D.ProdName,
	C.CustId,C.CustName,C.Age,C.DOB,C.CustGender,C.Nominee,C.Relation,C.Smoker,
	C.CustAddress,C.CustPhoneNo,C.Premium_payment_freq 

FROM
    PolicyEn.Customers AS C
    INNER JOIN PolicyEn.[Policy] AS P
    ON C.CustId = P.CustId
    INNER JOIN  PolicyEn.Products AS D
    ON D.ProdId = P.ProdId

ALTER PROCEDURE [PolicyEn].selectDetails
@cpno INT
--@cname VARCHAR(50),
--@dob DATE
AS
          SELECT p.PolicyNumber,p1.ProdName,p1.ProductLine,c.CustName,c.CustAddress,c.CustPhoneNo,c.CustGender,c.DOB,c.Smoker,c.Hobbies,c.Nominee,c.Relation,c.Premium_payment_freq,c.Age
		  FROM 
		  [PolicyEn].[Policy] p 
		  INNER JOIN [PolicyEn].[Products] p1 
		  ON (p.ProdId=p1.ProdId)
		  INNER JOIN
		  [PolicyEn].[Customers] c 
		  ON (c.CustId=p.CustId) 
		  WHERE c.CustId=@cpno OR p.PolicyNumber=@cpno --OR c.CustName=@cname OR c.DOB=@dob
		  --OR c.DOB=@dob;

		  

