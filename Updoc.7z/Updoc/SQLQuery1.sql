﻿CREATE SCHEMA [DocUpload] 

CREATE TABLE [DocUpload].[Uploads]
(
Id INT IDENTITY(1,1),
Docname VARCHAR(MAX)
)
DROP TABLE [DocUpload].[Uploads]
ALTER PROCEDURE [DocUpload].[upld]
@dname VARCHAR(MAX)
AS
   INSERT INTO [DocUpload].[Uploads] VALUES(@dname)