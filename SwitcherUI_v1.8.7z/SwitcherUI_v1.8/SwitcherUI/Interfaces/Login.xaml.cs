﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Entities;
using Exceptions;
using PolicyBusinessLayer;

namespace SwitcherUI
{
    /// <summary>
    /// Interaction logic for Login.xaml
    /// </summary>
    public partial class Login : UserControl, ISwitchable
    {
        static PolicyBL polBL = new PolicyBL();

        public Login()
        {
            InitializeComponent();
        }

        private void BtnLogin_Click(object sender, RoutedEventArgs e)
        {
            bool test = false;
            try
            {
                UserLogin objLogin = new UserLogin {
                    LoginID = Convert.ToInt32(txtLoginId.Text),
                    Password = txtPassword.Password
            };
                
                test = polBL.LoginBL(objLogin);

                if (test)
                {
                    Switcher.Switch(new HomePage());
                }
                else
                {
                    MessageBox.Show("INCORRECT PASSWORD OR USER ID", "Authentication Failed");
                    txtLoginId.Text = string.Empty;
                    txtPassword.Password = string.Empty;
                }
                
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            
        }

        public void UtilizeState(object state)
        {
            throw new NotImplementedException();
        }
    }
}
