﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Entities;
using Exceptions;
using PolicyBusinessLayer;
using System.ComponentModel;


using System.Data.SqlClient;
using System.Configuration;
using System.Data;

namespace SwitcherUI
{
    /// <summary>
    /// Interaction logic for EndorsementStatus.xaml
    /// </summary>
    public partial class EndorsementStatus : UserControl, ISwitchable
    {
        SqlConnection cn = null;

        SqlCommand cmd = null;

        SqlDataReader dr = null;


        static PolicyBL polBL = new PolicyBL();

        //IEnumerable<EndorsStatus> status = polBL.SelectUpdateDetailsBL();
        IEnumerable<CompleteDetails> s = polBL.SelectBL();

        public EndorsementStatus()
        {
           
            InitializeComponent();
            PopulateUI();
        }

      

        public void PopulateUI()
        {
            cmbBoxPolicyNo.ItemsSource = s;
            cmbBoxPolicyNo.DisplayMemberPath = "PolicyNumber";

        }

        public void UtilizeState(object state)
        {
            throw new NotImplementedException();
        }

        private void btnBack_Click(object sender, RoutedEventArgs e)
        {            
            Switcher.Switch(new HomePage());
        }

        private void CmbBoxPolicyNo_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            //this.cmbBoxPolicyNo.SelectionChanged += new SelectionChangedEventHandler(OnMyComboBoxChanged);
            //ComboBox doc = (ComboBox)cmbBoxPolicyNo.SelectedValue;
            //List<EndorsStatus> doc = (List<EndorsStatus>)cmbBoxPolicyNo.SelectedItem;
            //ticket.Class = flightFare.FlightClass;
            //ComboBoxItem doc = (ComboBoxItem)cmbBoxPolicyNo.SelectedValue;
            //string value = doc.Content.ToString();
            //MessageBox.Show(value);
            //var res1 = Convert.ToInt32(cmbBoxPolicyNo.SelectedValue);

            //string text = ((sender as ComboBox).SelectedItem as ComboBoxItem).Content as string;

            //var res = status.Where(s => s.PolicyNo.ToString() == cmbBoxPolicyNo.Text.ToString());
            //dgStatus.ItemsSource = res;

            //string query = "Select policyNo from PolicyEn.Status";
            //query += " WHERE policyNo = @Polno";
            //using (SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["con"].ConnectionString))
            //{
            //    using (SqlCommand cmd = new SqlCommand(query, con))
            //    {
            //        cmd.Parameters.AddWithValue("@Polno", cmbBoxPolicyNo.SelectedValue);
            //        using (SqlDataAdapter sda = new SqlDataAdapter(cmd))
            //        {
            //            DataTable dt = new DataTable();
            //            sda.Fill(dt);
            //            dgStatus.ItemsSource = dt.DefaultView;
            //        }
            //    }
            //}

            //MessageBox.Show(cmbBoxPolicyNo.Text);

        }

      
    }
}
