﻿CREATE SCHEMA [DocUpload] 

CREATE TABLE [DocUpload].[Uploads]
(
Id INT IDENTITY(1,1),
Docname VARCHAR(MAX)
)
DROP TABLE [DocUpload].[Uploads]


ALTER PROCEDURE [DocUpload].[upld]
@dname VARCHAR(MAX)
AS
   INSERT INTO [DocUpload].[Uploads] VALUES(@dname)


select * from [DocUpload].[Uploads]

select * from PolicyEn.AllDocuments

create table PolicyEn.AllDocuments(
PolicyNo INT,
[FileName] varchar(MAX)
foreign key(PolicyNo) REFERENCES PolicyEn.[Policy](PolicyNumber)
)

Drop table PolicyEn.AllDocuments

CREATE PROCEDURE PolicyEn.InsertDoc
@polno int,
@dname VARCHAR(MAX)
AS
   INSERT INTO PolicyEn.AllDocuments VALUES(@polno,@dname)

