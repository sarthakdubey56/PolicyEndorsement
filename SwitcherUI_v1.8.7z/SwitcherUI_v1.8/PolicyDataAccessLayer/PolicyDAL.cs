﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Entities;
using Exceptions;
using System.Windows;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;




namespace PolicyDataAccessLayer
{
    public class PolicyDAL
    {
        SqlConnection cn = null;

        SqlCommand cmd = null;

        SqlDataReader dr = null;

        //static List<Customer> objCustomer = new List<Customer>();
        //static List<Product> objProduct = new List<Product>();
        //static List<Policy> objPolicy = new List<Policy>();

        static List<CompleteDetails> objDetails = new List<CompleteDetails>();

        static List<Document> objFile = new List<Document>();
        static List<EndorsStatus> objStatus = new List<EndorsStatus>();

        public PolicyDAL()
        {
            cn = new SqlConnection(ConfigurationManager.ConnectionStrings["con"].ConnectionString);
        }






        //public IEnumerable<Customer> ViewCustomerDAL(Customer customer)
        //{
        //    try
        //    {
        //        cmd = new SqlCommand("PolicyEn.selectDetails @cID", cn);
        //        cmd.Parameters.AddWithValue("@cID", customer.CustomerId);
        //        cn.Open();
        //        dr = cmd.ExecuteReader();
        //        if (dr.HasRows)
        //        {
        //            while (dr.Read())
        //            {
        //                Customer cd = new Customer();

        //                cd.CustomerName = dr[3].ToString();
        //                cd.CustAddress = dr[4].ToString();
        //                cd.CustPhoneNo = dr[5].ToString();
        //                cd.CustomerGender = Convert.ToChar(dr[6]);
        //                cd.CustDOB = Convert.ToDateTime(dr[7]);
        //                cd.CustSmoker = dr[8].ToString();
        //                cd.Nominee = dr[10].ToString();
        //                cd.Relation = dr[11].ToString();
        //                cd.PremiumPayFrequency = dr[12].ToString();
        //                cd.Age = Convert.ToInt32(dr[13]);
        //                objCustomer.Add(cd);

        //            }
        //        }
        //        dr.Close();

        //    }
        //    catch (Exception)
        //    {
        //        throw;
        //    }
        //    finally
        //    {
        //        if (cn.State == System.Data.ConnectionState.Open)
        //            cn.Close();
        //    }
        //    return objCustomer;
        //}

        //public IEnumerable<Product> ViewProductDAL(Product product, Customer customer)
        //{
        //    try
        //    {
        //        cmd = new SqlCommand("PolicyEn.selectDetails @cID", cn);
        //        cmd.Parameters.AddWithValue("@cID", customer.CustomerId);
        //        cn.Open();
        //        dr = cmd.ExecuteReader();
        //        if (dr.HasRows)
        //        {
        //            while (dr.Read())
        //            {
        //                Product prod = new Product();
        //                prod.ProductName = dr[1].ToString();
        //                prod.ProductLine = dr[2].ToString();
        //                objProduct.Add(prod);
        //            }
        //        }
        //        dr.Close();

        //    }
        //    catch (Exception)
        //    {
        //        throw;
        //    }
        //    finally
        //    {
        //        if (cn.State == System.Data.ConnectionState.Open)
        //            cn.Close();
        //    }
        //    return objProduct;
        //}

        //public IEnumerable<Policy> ViewPolicyDAL(Policy policy, Customer customer)
        //{
        //    try
        //    {
        //        cmd = new SqlCommand("PolicyEn.selectDetails @cID", cn);
        //        cmd.Parameters.AddWithValue("@cID", customer.CustomerId);
        //        cn.Open();
        //        dr = cmd.ExecuteReader();
        //        if (dr.HasRows)
        //        {
        //            while (dr.Read())
        //            {
        //                Policy pol = new Policy();
        //                objPolicy.Add(pol);
        //            }
        //        }
        //        dr.Close();

        //    }
        //    catch (Exception)
        //    {
        //        throw;
        //    }
        //    finally
        //    {
        //        if (cn.State == System.Data.ConnectionState.Open)
        //            cn.Close();
        //    }
        //    return objPolicy;
        //}






       

        public IEnumerable<CompleteDetails> ViewDetailsDAL(CompleteDetails customer)
        {

            try
            {
                CompleteDetails cd = new CompleteDetails();
                cmd = new SqlCommand("PolicyEn.selectDetails @cID", cn);
                cmd.Parameters.AddWithValue("@cID", customer.CustomerId);
                cn.Open();
                dr = cmd.ExecuteReader();
                if (dr.HasRows)
                {
                    while (dr.Read())
                    {
                        

                        cd.PolicyNumber = Convert.ToInt32(dr[0]);
                        cd.ProductName = dr[1].ToString();
                        cd.ProductLine = dr[2].ToString();
                        cd.CustomerName = dr[3].ToString();
                        cd.CustAddress = dr[4].ToString();
                        cd.CustPhoneNo = dr[5].ToString();
                        cd.CustomerGender = Convert.ToChar(dr[6]);
                        cd.CustDOB = Convert.ToDateTime(dr[7]);
                        cd.CustSmoker = dr[8].ToString();
                        cd.Nominee = dr[10].ToString();
                        cd.Relation = dr[11].ToString();
                        cd.PremiumPayFrequency = dr[12].ToString();
                        cd.Age = Convert.ToInt32(dr[13]);
                        objDetails.Add(cd);

                    }
                }
                dr.Close();

            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                if (cn.State == System.Data.ConnectionState.Open)
                    cn.Close();
            }
            return objDetails;
        }

        public IEnumerable<CompleteDetails> SelectDAL()
        {

            try
            {
                cmd = new SqlCommand("PolicyEn.SelectAll", cn);
                cn.Open();
                dr = cmd.ExecuteReader();
                if (dr.HasRows)
                {
                    while (dr.Read())
                    {
                        CompleteDetails cd = new CompleteDetails();

                        cd.PolicyNumber = Convert.ToInt32(dr[0]);
                        cd.ProductLine = dr[1].ToString();
                        cd.ProductName = dr[2].ToString();
                        cd.CustomerId = Convert.ToInt32(dr[3]);
                        cd.CustomerName = dr[4].ToString();
                        cd.Age = Convert.ToInt32(dr[5]);
                        cd.CustDOB = Convert.ToDateTime(dr[6]);
                        cd.CustomerGender = Convert.ToChar(dr[7]);
                        cd.Nominee = dr[8].ToString();
                        cd.Relation = dr[9].ToString();
                        cd.CustSmoker = dr[10].ToString();
                        cd.CustAddress = dr[11].ToString();
                        cd.CustPhoneNo = dr[12].ToString();
                        cd.PremiumPayFrequency = dr[13].ToString();
                        objDetails.Add(cd);
                    }
                }
                dr.Close();

            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                if (cn.State == System.Data.ConnectionState.Open)
                    cn.Close();
            }
            return objDetails;
        }




        //public IEnumerable<Customer> SelectCustomerDAL()
        //{

        //    try
        //    {
        //        cmd = new SqlCommand("PolicyEn.SelectAll", cn);
        //        cn.Open();
        //        dr = cmd.ExecuteReader();
        //        if (dr.HasRows)
        //        {
        //            while (dr.Read())
        //            {
        //                Customer cd = new Customer();
                        
        //                cd.CustomerId = Convert.ToInt32(dr[3]);
        //                cd.CustomerName = dr[4].ToString();
        //                cd.Age = Convert.ToInt32(dr[5]);
        //                cd.CustDOB = Convert.ToDateTime(dr[6]);
        //                cd.CustomerGender = Convert.ToChar(dr[7]);
        //                cd.Nominee = dr[8].ToString();
        //                cd.Relation = dr[9].ToString();
        //                cd.CustSmoker = dr[10].ToString();
        //                cd.CustAddress = dr[11].ToString();
        //                cd.CustPhoneNo = dr[12].ToString();
        //                cd.PremiumPayFrequency = dr[13].ToString();
        //                objCustomer.Add(cd);
        //            }
        //        }
        //        dr.Close();

        //    }
        //    catch (Exception)
        //    {
        //        throw;
        //    }
        //    finally
        //    {
        //        if (cn.State == System.Data.ConnectionState.Open)
        //            cn.Close();
        //    }
        //    return objCustomer;
        //}

        //public IEnumerable<Product> SelectProductDAL()
        //{

        //    try
        //    {
        //        cmd = new SqlCommand("PolicyEn.SelectAll", cn);
        //        cn.Open();
        //        dr = cmd.ExecuteReader();
        //        if (dr.HasRows)
        //        {
        //            while (dr.Read())
        //            {
        //                Product prod = new Product();
        //                prod.ProductLine = dr[1].ToString();
        //                prod.ProductName = dr[2].ToString();
        //                objProduct.Add(prod);
        //            }
        //        }
        //        dr.Close();

        //    }
        //    catch (Exception)
        //    {
        //        throw;
        //    }
        //    finally
        //    {
        //        if (cn.State == System.Data.ConnectionState.Open)
        //            cn.Close();
        //    }
        //    return objProduct;
        //}

        //public IEnumerable<Policy> SelectPolicyDAL()
        //{

        //    try
        //    {
        //        cmd = new SqlCommand("PolicyEn.SelectAll", cn);
        //        cn.Open();
        //        dr = cmd.ExecuteReader();
        //        if (dr.HasRows)
        //        {
        //            while (dr.Read())
        //            {
        //                Policy pol = new Policy();
        //                pol.PolicyNumber = Convert.ToInt32(dr[0]);
        //                objPolicy.Add(pol);
        //            }
        //        }
        //        dr.Close();

        //    }
        //    catch (Exception)
        //    {
        //        throw;
        //    }
        //    finally
        //    {
        //        if (cn.State == System.Data.ConnectionState.Open)
        //            cn.Close();
        //    }
        //    return objPolicy;
        //}






        public bool UpdateDAL( Customer customer, Policy policy)
        {
            bool isUpdated = false;
            try
            {
                cmd = new SqlCommand("PolicyEn.updateCustomer", cn);
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@polno", policy.PolicyNumber);
                cmd.Parameters.AddWithValue("@cname", customer.CustomerName);
                cmd.Parameters.AddWithValue("@cdob", customer.CustDOB);
                cmd.Parameters.AddWithValue("@cgen", customer.CustomerGender);
                cmd.Parameters.AddWithValue("@nom ", customer.Nominee);
                cmd.Parameters.AddWithValue("@rel", customer.Relation);
                cmd.Parameters.AddWithValue("@csmoke", customer.CustSmoker);
                cmd.Parameters.AddWithValue("@cadd", customer.CustAddress);
                cmd.Parameters.AddWithValue("@cphno", customer.CustPhoneNo);
                cmd.Parameters.AddWithValue("@premium", customer.PremiumPayFrequency);
                cn.Open();
                cmd.ExecuteNonQuery();
                isUpdated = true;
                
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                if (cn.State == System.Data.ConnectionState.Open)
                    cn.Close();
            }
            return isUpdated;
        }

        public bool UploadDAL(int pol, string file)
        {
            bool isUploaded = false;

            try
            {
                cmd = new SqlCommand("PolicyEn.InsertDoc", cn); //Connected to Stored procedure with procedure name. 
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@polNo", pol);
                cmd.Parameters.AddWithValue("@dname", file);
                
                cn.Open();
                cmd.ExecuteNonQuery();
                isUploaded = true;
            }
            catch (Exception)
            {
                throw;
            }
            return isUploaded;
        }

        public IEnumerable<Document> SelectDocDAL()
        {

            try
            {
                cmd = new SqlCommand("Select * from PolicyEn.AllDocuments", cn);
                //cmd.Parameters.AddWithValue("@polno", pol);
                cn.Open();
                dr = cmd.ExecuteReader();
                if (dr.HasRows)
                {
                    while (dr.Read())
                    {
                        Document file = new Document();
                        file.Id = Convert.ToInt32(dr[0]);
                        file.FileName = dr[1].ToString();
                        objFile.Add(file);
                    }
                }
                dr.Close();

            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                if (cn.State == System.Data.ConnectionState.Open)
                    cn.Close();
            }
            return objFile;
        }

        public IEnumerable<EndorsStatus> SelectUpdateDetailsDAL()
        {

            try
            {
                cmd = new SqlCommand("Select * from PolicyEn.Status", cn);
                cn.Open();
                dr = cmd.ExecuteReader();
                if (dr.HasRows)
                {
                    while (dr.Read())
                    {
                        EndorsStatus status = new EndorsStatus();
                        status.PolicyNo = Convert.ToInt32(dr[0]);
                        status.Fields = dr[1].ToString();
                        status.Values = dr[2].ToString();
                        status.Status = dr[3].ToString();
                        objStatus.Add(status);
                    }
                }
                dr.Close();

            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                if (cn.State == System.Data.ConnectionState.Open)
                    cn.Close();
            }
            return objStatus;
        }

        public bool LoginDAL(UserLogin login)
        {
            bool IsLoggedIn = false;
            try
            {

                int loginId = login.LoginID;
                string password = login.Password;

                cmd = new SqlCommand("Select * from PolicyEn.[Login] where LoginId = @loginId and passwd = @password ", cn);
                cmd.Parameters.AddWithValue("@loginId", loginId );
                cmd.Parameters.AddWithValue("@password", password);
                cn.Open();
                cmd.ExecuteNonQuery();
                dr = cmd.ExecuteReader();

                if (dr.HasRows)
                {
                    int i = 0;
                    while (dr.Read())
                    {
                        i++;
                    }
                    if (i == 1)
                    {
                        IsLoggedIn = true;
                    }
                }
                

                

                
                dr.Close();
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                if (cn.State == System.Data.ConnectionState.Open)
                    cn.Close();
            }
            return IsLoggedIn;
            
        }
        

    }
}
