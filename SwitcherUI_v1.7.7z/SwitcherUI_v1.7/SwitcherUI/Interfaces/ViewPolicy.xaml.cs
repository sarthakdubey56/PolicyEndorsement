﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Entities;
using Exceptions;
using PolicyBusinessLayer;

using System.IO;
using Microsoft.Win32;

namespace SwitcherUI
{
    /// <summary>
    /// Interaction logic for ViewPolicy.xaml
    /// </summary>
    public partial class ViewPolicy : UserControl, ISwitchable
    {
        static PolicyBL polBL = new PolicyBL();

        CompleteDetails objDetails = new CompleteDetails();

        IEnumerable<Document> file = polBL.SelectDocBL();

        public ViewPolicy(CompleteDetails customer)
        {
            
            InitializeComponent();
            PopulateUI(customer);
            dgFileName.ItemsSource = file;
        }
        
        


        //public ViewPolicy(Customer customer, Product product, Policy policy)
        //{
        //    InitializeComponent();
        //    PopulateUI(customer, product, policy);
        //    dgFileName.ItemsSource = file;
        //}


        //public void PopulateUI(Customer customer, Product product, Policy policy)
        //{
        //    try
        //    {
        //        txtPolicyNumber.Text = policy.PolicyNumber.ToString();
        //        txtProductLine.Text = product.ProductLine.ToString();
        //        txtProductName.Text = product.ProductName.ToString();
        //        txtCustomerName.Text = customer.CustomerName.ToString();
        //        txtCustomerAge.Text = customer.Age.ToString();
        //        txtDateOfBirth.Text = customer.CustDOB.ToString();
        //        txtGender.Text = customer.CustomerGender.ToString();
        //        txtNominee.Text = customer.Nominee.ToString();
        //        txtRelation.Text = customer.Relation.ToString();
        //        txtSmoker.Text = customer.CustSmoker.ToString();
        //        txtAddress.Text = customer.CustAddress.ToString();
        //        txtPhoneNo.Text = customer.CustPhoneNo.ToString();
        //        txtPaymentFreq.Text = customer.PremiumPayFrequency.ToString();
        //        polBL.ViewCustomerBL(customer);
        //        polBL.ViewProductBL(product, customer);
        //        polBL.ViewPolicyBL(policy, customer);
        //    }
        //    catch (Exception ex)
        //    {

        //        MessageBox.Show(ex.Message);
        //    }
        //}

        public void PopulateUI(CompleteDetails customer)
        {
            try
            {
                txtPolicyNumber.Text = customer.PolicyNumber.ToString();
                txtProductLine.Text = customer.ProductLine.ToString();
                txtProductName.Text = customer.ProductName.ToString();
                txtCustomerName.Text = customer.CustomerName.ToString();
                txtCustomerAge.Text = customer.Age.ToString();
                txtDateOfBirth.Text = customer.CustDOB.ToString();
                txtGender.Text = customer.CustomerGender.ToString();
                txtNominee.Text = customer.Nominee.ToString();
                txtRelation.Text = customer.Relation.ToString();
                txtSmoker.Text = customer.CustSmoker.ToString();
                txtAddress.Text = customer.CustAddress.ToString();
                txtPhoneNo.Text = customer.CustPhoneNo.ToString();
                txtPaymentFreq.Text = customer.PremiumPayFrequency.ToString();
                polBL.ViewDetailsBL(customer);
            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message);
            }
        }

        public void UtilizeState(object state)
        {
            throw new NotImplementedException();
        }

        private void btnUpdate_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                Product objProd = new Product {
                    ProductLine = txtProductLine.Text,
                    ProductName = txtProductName.Text
                };

                Policy objPolicy = new Policy
                {
                    PolicyNumber = Convert.ToInt32(txtPolicyNumber.Text),
                };

                Customer objCust = new Customer
                {
                    CustomerName = txtCustomerName.Text,
                    Age = Convert.ToInt32(txtCustomerAge.Text),
                    CustDOB = Convert.ToDateTime(txtDateOfBirth.Text),
                    CustomerGender = Convert.ToChar(txtGender.Text),
                    Nominee = txtNominee.Text,
                    Relation = txtRelation.Text,
                    CustSmoker = txtSmoker.Text,
                    CustAddress = txtAddress.Text,
                    CustPhoneNo = txtPhoneNo.Text,
                    PremiumPayFrequency = txtPaymentFreq.Text
                };
                polBL.UpdateBL(objCust, objProd, objPolicy);
                MessageBox.Show("Update Succesfully");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnStatus_Click(object sender, RoutedEventArgs e)
        {
            Switcher.Switch(new EndorsementStatus());
        }


        private void btnUploadDoc_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                Stream checkStream = null;
                OpenFileDialog dlg = new OpenFileDialog();
                dlg.Multiselect = true;
                dlg.Filter = "All Image Files | *.*";
                Nullable<bool> result = dlg.ShowDialog();
                if (result == true)
                {
                    try
                    {
                        if ((checkStream = dlg.OpenFile()) != null)
                        {
                            var filename = dlg.FileName;
                            polBL.UploadBL(Convert.ToInt32(txtPolicyNumber.Text), filename);
                            dgFileName.ItemsSource = file;

                            MessageBox.Show("Successfully done", filename);
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Error: Could not read file from disk. Original error: " + ex.Message);
                    }

                }
                else
                {

                    MessageBox.Show("Problem occured, try again later");

                }
            }
            catch (Exception)
            {
                throw;
            }
        }

        private void BtnSearch_Click(object sender, RoutedEventArgs e)
        {
            Switcher.Switch(new SearchPolicy());
        }

        
    }
}
