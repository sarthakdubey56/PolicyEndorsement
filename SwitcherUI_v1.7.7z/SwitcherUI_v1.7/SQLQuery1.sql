﻿create table PolicyEn.AllDocuments(
PolicyNo INT,
[FileName] varchar(MAX)
foreign key(PolicyNo) REFERENCES PolicyEn.[Policy](PolicyNumber)
)

select * from PolicyEn.AllDocuments

select * from PolicyEn.Customers
select * from PolicyEn.[Policy]

select * from airline.FlightClass

insert into PolicyEn.AllDocuments values(100004, 'gksjfabsdfzbsdfnbestdnbdjv'),
(100004, 'jhfkgijvugfdxnxfgdnfghleksjfh');

drop table PolicyEn.AllDocuments

ALTER PROCEDURE [PolicyEn].updateCustomer
@cname VARCHAR(50),
@cdob DATE,
@cgen VARCHAR(50),
@nom VARCHAR(50),
@rel VARCHAR(50),
@csmoke VARCHAR(50),
@cadd VARCHAR(50),
@cphno VARCHAR(50),
@premium VARCHAR(50),


@Ocadd VARCHAR(50),
@polno INT
AS
Begin
	Select  
	@Ocadd = CustAddress
	from [PolicyEn].[Customers]WHERE P1.PolicyNumber = @polno;

	  UPDATE [PolicyEn].[Customers] SET Age = DATEDIFF(year,@cdob,GETDATE())  FROM [PolicyEn].[Customers] C1 INNER JOIN  [PolicyEn].[Policy] P1 ON (C1.CustId = P1.CustId) WHERE P1.PolicyNumber IN (@polno);
      UPDATE [PolicyEn].[Customers] SET CustName=@cname,Smoker=@csmoke,DOB=@cdob,CustAddress=@cadd,CustPhoneNo=@cphno,CustGender=@cgen,Relation=@rel,Nominee=@nom,Premium_payment_freq=@premium  FROM [PolicyEn].[Customers] C1 INNER JOIN  [PolicyEn].[Policy] P1 ON (C1.CustId = P1.CustId)WHERE P1.PolicyNumber IN (@polno);

	  if @Ocadd != @cadd
	  Begin
		Insert into PolicyEn.[Status] values (@polno,@cadd,'pending...');
	  End
End


Create table PolicyEn.[Status](
policyNo int,
fields varchar(50),
[values] varchar(50),
[status] varchar(20),
foreign Key(policyNo) REFERENCES PolicyEn.[Policy](PolicyNumber)
);

select * from PolicyEn.[Status]

drop table PolicyEn.[Status]


ALTER PROCEDURE [PolicyEn].updateCustomer
@cname VARCHAR(50),
@cdob DATE,
@cgen VARCHAR(50),
@nom VARCHAR(50),
@rel VARCHAR(50),
@csmoke VARCHAR(50),
@cadd VARCHAR(50),
@cphno VARCHAR(50),
@premium VARCHAR(50),
@polno INT 
AS
DECLARE 
@Ocname VARCHAR(50),
@Ocdob DATE,
@Ocgen VARCHAR(50),
@Onom VARCHAR(50),
@Orel VARCHAR(50),
@Ocsmoke VARCHAR(50),
@Ocadd VARCHAR(50),
@Ocphno VARCHAR(50),
@Opremium VARCHAR(50)
	Select @Ocname = C.CustName,@Ocdob = C.DOB,@Ocgen = C.CustGender,@Onom = C.Nominee,@Orel = C.Relation,@Ocsmoke = C.Smoker, 
	@Ocadd = C.CustAddress,@Ocphno = C.CustPhoneNo,@Opremium = C.Premium_payment_freq
	from [PolicyEn].[Customers] C inner join [PolicyEn].[Policy] P on c.CustId = P.CustId where P.PolicyNumber = @polno;
Begin
		
	  Delete from PolicyEn.[Status] where policyNo = @polNo;

	  UPDATE [PolicyEn].[UpdatedCustomer] SET Age = DATEDIFF(year,@cdob,GETDATE())  FROM [PolicyEn].[UpdatedCustomer] C1 
									INNER JOIN  [PolicyEn].[Policy] P1 ON (C1.CustId = P1.CustId) 
									WHERE P1.PolicyNumber IN (@polno);
      UPDATE [PolicyEn].[UpdatedCustomer] SET CustName=@cname,Smoker=@csmoke,DOB=@cdob,CustAddress=@cadd,
									CustPhoneNo=@cphno,CustGender=@cgen,Relation=@rel,Nominee=@nom,
									Premium_payment_freq=@premium  FROM [PolicyEn].[UpdatedCustomer] C1 
									INNER JOIN  [PolicyEn].[Policy] P1 ON (C1.CustId = P1.CustId)
									WHERE P1.PolicyNumber IN (@polno);

	  If @Ocname != @cname
	  Begin
		Insert into PolicyEn.[Status] values (@polno,'Customer Name',@cname,'pending...');
	  End
	  If @Ocdob != @cdob
	  Begin
		Insert into PolicyEn.[Status] values (@polno,'Date of Birth',@cdob,'pending...');
	  End
	  If @Ocgen != @cgen
	  Begin
		Insert into PolicyEn.[Status] values (@polno,'Gender',@cgen,'pending...');
	  End
	  If @Orel != @rel
	  Begin
		Insert into PolicyEn.[Status] values (@polno,'Relation',@rel,'pending...');
	  End
	  If @Ocsmoke != @csmoke
	  Begin
		Insert into PolicyEn.[Status] values (@polno,'Smoker',@csmoke,'pending...');
	  End
	  If @Ocadd != @cadd
	  Begin
		Insert into PolicyEn.[Status] values (@polno,'Address',@cadd,'pending...');
	  End
	  If @Ocphno != @cphno
	  Begin
		Insert into PolicyEn.[Status] values (@polno,'Phone No',@cphno,'pending...');
	  End
	  If @Opremium != @premium
	  Begin
		Insert into PolicyEn.[Status] values (@polno,'Payment Frequency',@premium,'pending...');
	  End
End
 

 SELECT * FROM [PolicyEn].[Customers];




 Select * Into PolicyEn.UpdatedCustomer From PolicyEn.Customers

 Select * from PolicyEn.UpdatedCustomer