﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace SwitcherUI
{ 
    /// <summary>
    /// Interaction logic for SearchPolicy.xaml
    /// </summary>
    public partial class SearchPolicy : UserControl, ISwitchable
    {
        public SearchPolicy()
        {
            InitializeComponent();
        }

        public void UtilizeState(object state)
        {
            throw new NotImplementedException();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            Switcher.Switch(new HomePage());
        }

        #region SearchBox Event Handlers
        private void ComboBoxItem_Selected_NameDOB(object sender, RoutedEventArgs e)
        {           
            datePkrDOB.Visibility = Visibility.Visible;
            lblSearchDOB.Visibility = Visibility.Visible;
            cmbBoxSearchName.Visibility = Visibility.Visible;
            lblSearchName.Visibility = Visibility.Visible;

            datePkrDOB.IsEnabled = true;
            lblSearchDOB.IsEnabled = true;
            cmbBoxSearchName.IsEnabled = true;
            lblSearchName.IsEnabled = true;
        }

        private void ComboBoxItem_Unselected_NameDOB(object sender, RoutedEventArgs e)
        {
            datePkrDOB.Visibility = Visibility.Hidden;
            lblSearchDOB.Visibility = Visibility.Hidden;
            cmbBoxSearchName.Visibility = Visibility.Hidden;
            lblSearchName.Visibility = Visibility.Hidden;

            datePkrDOB.IsEnabled = false;
            lblSearchDOB.IsEnabled = false;
            cmbBoxSearchName.IsEnabled = false;
            lblSearchName.IsEnabled = false;
        }

        private void ComboBoxItem_Selected_PolNum(object sender, RoutedEventArgs e)
        {
            cmbBoxSearchPolNum.Visibility = Visibility.Visible;
            lblSearchPolNum.Visibility = Visibility.Visible;

            cmbBoxSearchPolNum.IsEnabled = true;
            lblSearchPolNum.IsEnabled = true;
        }

        private void ComboBoxItem_Unselected_PolNum(object sender, RoutedEventArgs e)
        {
            cmbBoxSearchPolNum.Visibility = Visibility.Hidden;
            lblSearchPolNum.Visibility = Visibility.Hidden;

            cmbBoxSearchPolNum.IsEnabled = false;
            lblSearchPolNum.IsEnabled = false;
        }

        private void ComboBoxItem_Selected_CustID(object sender, RoutedEventArgs e)
        {
            cmbBoxSearchCustID.Visibility = Visibility.Visible;
            lblSearchCustID.Visibility = Visibility.Visible;

            cmbBoxSearchCustID.IsEnabled = true;
            lblSearchCustID.IsEnabled = true;
        }

        private void ComboBoxItem_Unselected_CustID(object sender, RoutedEventArgs e)
        {
            cmbBoxSearchCustID.Visibility = Visibility.Hidden;
            lblSearchCustID.Visibility = Visibility.Hidden;

            cmbBoxSearchCustID.IsEnabled = false;
            lblSearchCustID.IsEnabled = false;
        }
        #endregion
    }
}
