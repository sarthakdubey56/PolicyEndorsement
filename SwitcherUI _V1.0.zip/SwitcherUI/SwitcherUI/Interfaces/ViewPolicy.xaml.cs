﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace SwitcherUI
{
    /// <summary>
    /// Interaction logic for ViewPolicy.xaml
    /// </summary>
    public partial class ViewPolicy : UserControl, ISwitchable
    {
        public ViewPolicy()
        {
            InitializeComponent();
        }

        public void UtilizeState(object state)
        {
            throw new NotImplementedException();
        }

        private void btnUpdate_Click(object sender, RoutedEventArgs e)
        {

        }

        private void btnStatus_Click(object sender, RoutedEventArgs e)
        {
            Switcher.Switch(new EndorsementStatus());
        }

        private void btnBrowse_Click(object sender, RoutedEventArgs e)
        {

        }

        private void btnUploadDoc_Click(object sender, RoutedEventArgs e)
        {

        }
    }
}
