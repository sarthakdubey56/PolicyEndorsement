﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exceptions
{
    public class Policy_Exception: ApplicationException
    {
        public Policy_Exception()
            : base()
        {
        }

        public Policy_Exception(string msg)
            : base(msg)
        {
        }
    }
}
