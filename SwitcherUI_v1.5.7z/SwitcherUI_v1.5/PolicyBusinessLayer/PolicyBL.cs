﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using PolicyDataAccessLayer;
using Entities;
using Exceptions;

namespace PolicyBusinessLayer
{
    public class PolicyBL
    {
        public IEnumerable<CompleteDetails> ViewDetailsBL(CompleteDetails sel)
        {
            IEnumerable<CompleteDetails> objDetails = null;
            try
            {

                PolicyDAL polDAL = new PolicyDAL();
                objDetails = polDAL.ViewDetailsDAL(sel);

            }
            catch (Exception)
            {
                throw;
            }

            return objDetails;
        }

        public IEnumerable<CompleteDetails> SelectBL()
        {
            IEnumerable<CompleteDetails> objDetails = null;
            try
            {

                PolicyDAL polDAL = new PolicyDAL();
                objDetails = polDAL.SelectDAL();

            }
            catch (Exception)
            {
                throw;
            }

            return objDetails;
        }

        public bool UpdateBL(CompleteDetails sel)
        {
            bool isUpdated = false;
            try
            {
                    PolicyDAL polDAL = new PolicyDAL();
                    isUpdated = polDAL.UpdateDAL(sel);

            }
            catch (Exception)
            {
                throw;
            }
            return isUpdated;
        }

        public bool UploadBL(string file)
        {
            bool filename = false;
            try
            {
                PolicyDAL polDAL = new PolicyDAL();
                filename = polDAL.UploadDAL(file);

            }
            catch (Exception)
            {
                throw;
            }
            return filename;
        }


        public IEnumerable<Document> SelectDocBL()
        {
            IEnumerable<Document> objFile = null;
            try
            {

                PolicyDAL polDAL = new PolicyDAL();
                objFile = polDAL.SelectDocDAL();

            }
            catch (Exception)
            {
                throw;
            }

            return objFile;
        }

        public IEnumerable<EndorsStatus> SelectUpdateDetailsBL()
        {
            IEnumerable<EndorsStatus> objStatus = null;
            try
            {

                PolicyDAL polDAL = new PolicyDAL();
                objStatus = polDAL.SelectUpdateDetailsDAL();

            }
            catch (Exception)
            {
                throw;
            }

            return objStatus;
        }
    }
}
