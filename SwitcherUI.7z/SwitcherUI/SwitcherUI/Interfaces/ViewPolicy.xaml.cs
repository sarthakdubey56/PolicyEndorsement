﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Data.SqlClient;
using System.Configuration;

namespace SwitcherUI
{
    /// <summary>
    /// Interaction logic for ViewPolicy.xaml
    /// </summary>
    public partial class ViewPolicy : UserControl, ISwitchable
    {

        EndorsementStatus status = new EndorsementStatus();

        SqlConnection cn = new SqlConnection(ConfigurationManager.ConnectionStrings["con"].ConnectionString);

        SqlCommand cmd = null;

        SqlDataReader dr = null;

        public ViewPolicy()
        {
            InitializeComponent();
            PopulateUI();
        }

        public void PopulateUI()
        {
            try
            {
                cmd = new SqlCommand("PolicyEn.selectDetails 1005", cn);
                cn.Open();
                dr = cmd.ExecuteReader();
                if (dr.HasRows)
                {
                    while (dr.Read())
                    {
                        txtPolicyNumber.Text = dr[0].ToString();
                        txtProductName.Text = dr[1].ToString();
                        txtProductLine.Text = dr[2].ToString();
                        txtCustomerName.Text = dr[3].ToString();
                        txtAddress.Text = dr[4].ToString();
                        txtPhoneNo.Text = dr[5].ToString();
                        txtGender.Text = dr[6].ToString();
                        txtDateOfBirth.Text = dr[7].ToString();
                        txtSmoker.Text = dr[8].ToString();
                        txtNominee.Text = dr[10].ToString();
                        txtRelation.Text = dr[11].ToString();
                        txtPaymentFreq.Text = dr[12].ToString();
                        txtCustomerAge.Text = dr[13].ToString();

                    }
                }
                dr.Close();

            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                if (cn.State == System.Data.ConnectionState.Open)
                    cn.Close();
            }
        }

        public void UtilizeState(object state)
        {
            throw new NotImplementedException();
        }

        private void btnUpdate_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                cmd = new SqlCommand("PolicyEn.updateCustomer", cn);
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@polno", txtPolicyNumber.Text);
                cmd.Parameters.AddWithValue("@cname", txtCustomerName.Text);
                cmd.Parameters.AddWithValue("@cdob", Convert.ToDateTime(txtDateOfBirth.Text));
                cmd.Parameters.AddWithValue("@cgen", txtGender.Text);
                cmd.Parameters.AddWithValue("@nom ", txtNominee.Text);
                cmd.Parameters.AddWithValue("@rel", txtRelation.Text);
                cmd.Parameters.AddWithValue("@csmoke", txtSmoker.Text);
                cmd.Parameters.AddWithValue("@cadd", txtAddress.Text);
                cmd.Parameters.AddWithValue("@cphno", txtPhoneNo.Text);
                cmd.Parameters.AddWithValue("@premium", txtPaymentFreq.Text);

                cn.Open();
                cmd.ExecuteNonQuery();
                MessageBox.Show("Records are Successfully Updated");
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                if (cn.State == System.Data.ConnectionState.Open)
                    cn.Close();
            }
        }

        private void btnStatus_Click(object sender, RoutedEventArgs e)
        {
            Switcher.Switch(new EndorsementStatus());
        }

        private void btnBrowse_Click(object sender, RoutedEventArgs e)
        {

        }

        private void btnUploadDoc_Click(object sender, RoutedEventArgs e)
        {

        }
    }
}
